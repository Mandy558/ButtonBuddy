## Connect to Wi‑Fi (Windows 11)
1) Click the **Network** icon on the right of the taskbar.
2) Ensure **Wi‑Fi** is **On**.
3) Select your **network** → **Connect**.
4) Enter the **password** (case‑sensitive).
5) Wait for **Connected, secured**.
