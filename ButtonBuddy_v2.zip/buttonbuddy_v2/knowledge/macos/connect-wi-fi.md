## Connect to Wi‑Fi (macOS)
1) Click the **Wi‑Fi** icon in the menu bar.
2) Make sure **Wi‑Fi** is **On**.
3) Click your **network name** → enter the **password** → **Join**.
