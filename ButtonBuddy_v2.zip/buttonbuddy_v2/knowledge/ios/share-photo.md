## Share a Photo by Email (iPhone)
1) Open **Photos** and select a photo.
2) Tap the **Share** icon → **Mail**.
3) Enter recipient + subject → **Send**.
