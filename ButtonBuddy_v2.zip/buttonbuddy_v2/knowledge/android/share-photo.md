## Share a Photo by Email (Android)
1) Open **Photos** (or Gallery) and select a photo.
2) Tap **Share** → **Gmail** (or Email).
3) Type the recipient, add a short message → **Send**.
