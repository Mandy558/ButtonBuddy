# ButtonBuddy — Offline Tech Helper (v2)

A **local, no-internet** desktop agent that guides anyone through everyday tech tasks (Wi‑Fi, Bluetooth, photos, Zoom). Powered by **gpt-oss** via `llama-cpp-python`.  
This version adds **Memory Mode** (remembers your last task) and a **Refusal Guard** (politely declines internet-only requests).

## Features
- Offline LLM (no network calls)
- Big-button desktop UI (Electron)
- Knowledge Packs (Markdown: Windows/macOS/iOS/Android)
- **NEW:** Memory Mode (local JSON at `data/memory.json`)
- **NEW:** Refusal Guard (detects weather/news/etc. and suggests offline alternatives)

## Quickstart
```bash
# Backend
cd backend
python -m venv .venv && source .venv/bin/activate  # Windows: .venv\Scripts\activate
pip install -r requirements.txt
# Configure model
cp ../inference/.env.example ../inference/.env
# edit ../inference/.env and set MODEL_PATH to your local GGUF (e.g., gpt-oss-20b-q4_0.gguf)
uvicorn server:app --port 8000

# Frontend
cd ../app
npm install
npm start
```

### GPU Acceleration (optional)
If you installed a CUDA/Metal build of `llama-cpp-python`, set in `inference/.env`:
```
N_GPU_LAYERS=35
CTX_LEN=4096
```
> Larger values improve speed/quality but use more VRAM.

## Devpost Notes
- **Category fit**: Best Local Agent (primary), For Humanity (secondary).  
- **Proof of offline**: record with Wi‑Fi disabled; ask for weather (refuse) vs. a local task (succeeds).  
- **Repo clarity**: this README + `.env` + run script should let judges repro quickly.
