from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
import os, json, re
from typing import Optional

try:
    from llama_cpp import Llama
except Exception:
    Llama = None

BASE_DIR = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
DATA_PATH = os.path.join(BASE_DIR, "data", "memory.json")
os.makedirs(os.path.dirname(DATA_PATH), exist_ok=True)
if not os.path.exists(DATA_PATH):
    with open(DATA_PATH, "w", encoding="utf-8") as f:
        json.dump({"last_prompt": "", "last_response": ""}, f)

MODEL_PATH = os.getenv("MODEL_PATH", "").strip()
N_CTX = int(os.getenv("CTX_LEN", "4096"))
N_GPU_LAYERS = int(os.getenv("N_GPU_LAYERS", "0"))

app = FastAPI(title="ButtonBuddy Backend v2", version="0.2.0")

llm = None
if Llama is not None and MODEL_PATH and os.path.exists(MODEL_PATH):
    try:
        llm = Llama(model_path=MODEL_PATH, n_ctx=N_CTX, n_gpu_layers=N_GPU_LAYERS, verbose=False)
    except Exception:
        llm = None

INSTRUCTIONS = '''You are ButtonBuddy, an OFFLINE assistant.
- If a request needs internet (weather, news, maps, email, social media), politely refuse and suggest offline alternatives.
- Prefer concise, numbered step-by-step instructions for everyday tech tasks.
- If user mentions platform (Windows/macOS/iOS/Android), adapt steps accordingly.
- Keep language friendly and simple.'''

ONLINE_KEYWORDS = re.compile(r"(weather|forecast|news|email|gmail|youtube|google|map|maps|twitter|x\.com|tiktok|instagram|whatsapp call|uber|lyft|spotify|netflix)", re.I)

class GenerateReq(BaseModel):
    prompt: str
    system: Optional[str] = None
    max_tokens: int = 512
    temperature: float = 0.6
    remember: bool = True

class GuideReq(BaseModel):
    platform: str
    topic: str
    remember: bool = True

@app.get("/health")
def health():
    return {
        "ok": True,
        "model_loaded": bool(llm is not None),
        "model_path_set": bool(MODEL_PATH),
        "offline": True
    }

def load_memory():
    try:
        with open(DATA_PATH, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return {"last_prompt": "", "last_response": ""}

def save_memory(last_prompt: str, last_response: str):
    try:
        with open(DATA_PATH, "w", encoding="utf-8") as f:
            json.dump({"last_prompt": last_prompt, "last_response": last_response}, f)
    except Exception:
        pass

@app.get("/memory")
def get_memory():
    return load_memory()

@app.post("/memory/clear")
def clear_memory():
    save_memory("", "")
    return {"ok": True}

@app.post("/generate")
def generate(req: GenerateReq):
    # Refusal guard for online-only topics
    if ONLINE_KEYWORDS.search(req.prompt):
        text = ("I work entirely offline, so I can’t access online services like weather, news, maps, or email. "
                "But I can still help with **offline tasks** such as connecting to Wi‑Fi, pairing Bluetooth headphones, "
                "organizing photos, or creating documents. What would you like to do?")
        if req.remember:
            save_memory(req.prompt, text)
        return {"text": text, "refused": True}

    if llm is None:
        text = "(Model not loaded) Set MODEL_PATH in inference/.env and restart backend."
        if req.remember:
            save_memory(req.prompt, text)
        return {"text": text}

    system = req.system or INSTRUCTIONS
    prompt = f"<|system|>\n{system}\n<|user|>\n{req.prompt}\n<|assistant|>\n"
    try:
        out = llm(prompt, max_tokens=req.max_tokens, temperature=req.temperature, stop=["</s>"])
        text = out.get("choices", [{}])[0].get("text", "").strip()
        if req.remember:
            save_memory(req.prompt, text)
        return {"text": text}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

def read_md(path:str)->str:
    try:
        with open(path, "r", encoding="utf-8") as f:
            return f.read()
    except Exception:
        return ""

@app.post("/guide")
def guide(req: GuideReq):
    platform = req.platform.lower()
    topic = req.topic.lower().replace(" ", "-")
    base = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "knowledge"))
    candidate = os.path.join(base, platform, f"{topic}.md")
    if not os.path.exists(candidate):
        text = "No local guide found. Try /generate instead (e.g., 'Connect to Wi‑Fi on Windows 11')."
        if req.remember:
            save_memory(f"guide:{platform}:{topic}", text)
        return {"title": req.topic, "steps": text}

    content = read_md(candidate)
    if req.remember:
        save_memory(f"guide:{platform}:{topic}", content)
    return {"title": req.topic, "steps": content}
